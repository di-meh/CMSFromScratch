<?php
	include "header.php";
?>


<?php


	$name = "skrzypczyk";
	$age = 20;
	$adult = true;
	$size = 1.96;
	$average = null; 


	/*
		Concaténation : .
	*/

	echo "Bonjour ".$name;

	// + - / * %

	/*

	Incrémentation 

	$i = 0;
	++$i ; //Pré incrémentation
	$i++ ; //Post incrémentation
	$i += 1 ;
	$i = $i + 1;
	
	*/

	$i = 0;
	$i++;
	echo $i; //1
	echo ++$i; //2
	echo $i+1; //3
	echo $i++; //2
	echo $i; //3

	echo $i=$i+2; //5
	//echo $j+2; //2 ou erreur
	echo $i; //5
	echo $i=+2; //2



	if($age < 18) 
		echo "mineur";
	else if( $age == 18)
		echo "tout juste majeur";
	else
		echo "majeur";


	if($adult){
		echo "Vous êtes des adultes";
	}else{
		echo "Vous n'êtes pas des adultes";
	}

	// condition ternaire : instruction (condition)?vrai:faux;

	echo ($adult)?"Vous êtes des adultes":"Vous n'êtes pas des adultes";


	$civility = "Mme";


	switch ($civility) {
		case 'Mr':
			echo "Bonjour Monsieur";
			break;
		case 'Mme':
			echo "Bonjour Madame";
		default:
			echo "Bonjour";
	}


	// le null coalescent

	echo $firstname??"Inconnu";

	if( empty($firstname))
		echo "Inconnu";
	else{
		echo $firstname;
	}



	/*
		BOUCLES 

		FOR : itération connu
		WHILE : itération inconnu
		DO WHILE : au moins une itération
		FOREACH : Parcourir un tableau

	*/

	for ($cpt = 0 ; $cpt < 10 ; $cpt++ ) { 

	}


	$myNumber = 4;
	$tentatives = 0;

	do{
		$dice = rand(1,6);
		$tentatives++;
	}while ( $dice != $myNumber);


	
	echo "Il a fallu ".$tentatives." pour trouver le chiffre ".$myNumber;	




	/* Tableaux */


	$student = ["Marie", "PIERRE", 18];

	//$student = [0=>"Marie", 1=>"PIERRE", 2=>18];

	echo $student[1];

	//echo $student; // Error : Array to string conversation
	print_r($student);
	var_dump($student);

	$student[]=15;


	$student = ["firstname"=>"Marie", "lastname"=>"PIERRE", "age"=>18];

	$student[]=15;


	// Dimension ?  5D

	$esgi = [
					'IW'=>[	
						"3A"=>[
							"classe 1"=>[

								0=>["firstname"=>"Marie", "lastname"=>"PIERRE", "age"=>18],
								1=>["firstname"=>"Alexandre", "lastname"=>"BAUDRY", "age"=>21],
								2=>["firstname"=>"Errol", "lastname"=>"FIESCHI", "age"=>23],
							],
							"classe 2"=>[],
							"classe 3"=>[],
						],
						"4A"=>[],
						"5A"=>[],
					],
					'MCSI'=>[],
					'AL'=>[],
			];




			//Afficher Errol
			echo $esgi['IW']["3A"]["classe 1"][2]["firstname"];


	//foreach ($esgi['IW']["3A"]["classe 1"] as $student)		
	foreach ($esgi['IW']["3A"]["classe 1"] as $key => $student) {
		echo "<li>".$student["lastname"];
	}	



	//camel case : monSuperFonctionDeCoursDePhp
	$maVariable = "Yves";

	function helloYou($maVariable){
		//global $maVariable;
		echo "hello ".$maVariable;
	}


	helloYou($maVariable);




	function cleanLastname(&$lastname){
		$lastname = mb_strtoupper(trim($lastname));

	}


	$lastname = "SkrZypczyk    ";
	cleanLastname($lastname);
	echo $lastname;


	

?>






<?php

	include "footer.php";
?>