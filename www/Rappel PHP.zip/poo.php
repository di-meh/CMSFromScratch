<?php

class SQL{

	public function __construct(){
		//se connecter à la bdd VIA un singleton
	}

	public function save(){
		//faire une insertion ou un update en bdd
	}


}


class Page extends SQL{
	private $title;
	....
}


class User extends SQL{

	private $firstname;
	private $lastname;
	private $email;
	private $pwd;
	private $age;


	public function __construct($showMess = false){
		if($showMess)
			echo "Création d'un utilisateur";
	}

	public function __toString(){
		return $this->getFirstname();
	}

	public function __get($name){
		// $name = firstname
		// Appel dynamique d'un attribut
		// $this->$name = $this->firstname
		
		if(in_array($name, ["firstname"])) return null;
		
		return $this->$name??null;
	

		//return (in_array($name, ["firstname"]))?null:($this->$name??null);
	}

	//SETTERS set = définir
	public function setFirstname($firstname){
		$this->firstname = ucfirst(mb_strtolower(trim($firstname)));
	}
	public function setLastname($lastname){
		$this->lastname = mb_strtoupper(trim($lastname));
	}
	public function setEmail($email){
		$this->email = mb_strtolower(trim($email));
	}
	public function setPwd($pwd){
		$this->pwd = password_hash($pwd, PASSWORD_DEFAULT);
	}
	public function setAge($age){
		$this->age = $age;
	}
	
	//GETTERS get=obtenir
	/*
	public function getFirstname(){
		return $this->firstname;
	}
	*/

	public function __destruct(){
		echo "Destruction de l'utilisateur";
	}

}

$myUser = new User(false);
$myUser->setFirstname("     yvEs");
$myUser->setLastname("SkrzyPCzyk ");
$myUser->setEmail("   y.SKRZYPCZYK@GMAIL.com");
$myUser->setPwd("Test1234");
$myUser->setAge(20);

$myUser->save();


$myPage = new Page();
...
$myPage->save();




echo "Bonjour ". $myUser->lastname;

//echo "test";
//echo $myUser;

/*
$myUser->firstname = "YvEs";
$myUser->lastname = "SkrzyPCzyk ";
$myUser->email = "   y.SKRZYPCZYK@GMAIL.com";
$myUser->pwd = "Test1234";
$myUser->age = 20;
*/




echo "<pre>";
print_r($myUser);


/*
	plan maison
		toit = 1
		murs = 4
		porte = 1
		fenetre = 1
		fondation = 1

	plan = class
*/
/*
//Convention de nommage : Pascal Case
class House{

	//Attributs OU Propriétés
	private $roof = 1;
	private $walls = 4;
	private $door = 1;
	private $window = 1;
	private $fundation = 1;
	private $stage = 0;

	//Methods
	public function addStage(){
		//$this correspond à l'objet en cours
		//si j'ai fait $myHouse->addStage();
		//alors $this c'est $myHouse
		$this->stage++;
		$this->window++;
		$this->walls+=4;
	}


}

//Création d'une maison à partir du plan
//Création d'un objet à partir d'une class
//L'objet c'est l'instance de la class House
$myHouse = new House;
//$myHouse->stage += 1;
//$myHouse->walls += 4;
//$myHouse->window += 1;
$myHouse->addStage();
$myHouse->addStage();

print_r($myHouse);

*/









