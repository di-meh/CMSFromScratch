<?php


class Vehicule{
	protected $roues = 2;
	private $vitesse = 0;

	public function __construct(){
		echo "Nouveau véhicule";
	}

	public function accelerer(){
		$this->vitesse += $this->acceleration;
	}
}

class Voiture extends Vehicule{
	private $volant;
	protected $acceleration = 10;

	//Surcharge
	public function __construct(){
		parent::__construct();
		$this->roues += 2;
	}
}



class Moto extends Vehicule{
	private $guidon;
	protected $acceleration = 20;
}




$maMoto = new Moto();
$maMoto->accelerer();
$maMoto->accelerer();
$maMoto->accelerer();



$maVoiture = new Voiture();
$maVoiture->accelerer();
$maVoiture->accelerer();
$maVoiture->accelerer();


/*
echo "<pre>";

print_r($maMoto);
print_r($maVoiture);
*/