<?php

	session_start();


	//setcookie("pseudo", "Prof", time()+10);

	//echo "Bonjour ".$_COOKIE['pseudo'];
	//setcookie("login", true);

	//Session


	//$_SESSION["email"] = "y.skrzypczyk@gmail.com";

	//echo $_SESSION["email"];