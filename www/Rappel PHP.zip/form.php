<?php

	// Variables globales
	$variable;
	$test;


	//Variables SUPER GLOBALES
	/*
		POST, GET, REQUEST, COOKIE, 
		SESSION, ENV, FILES, SERVER

		Commence par $_
		Toujours en majuscule
		Accessible partout
		Créé et alimenté par le serveur
		Des tableaux
	*/
	//echo "<pre>";
	//print_r($_ENV);

/*
http://localhost/form.php?
email=y.skrzypczyk%40gmail.com
&pwd=Test1234

*/

	print_r($_FILES);

?>


<form method="POST" enctype="multipart/form-data">
	<input type="email" name="email">
	<input type="password" name="pwd">
	<input type="file" name="avatar">
	<input type="submit" value="Se connecter">
</form>













