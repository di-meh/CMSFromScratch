<?php


class Helpers{

	public static function cleanLastname($lastname){
		return mb_strtoupper(trim($lastname));
	}

	public static function p($array){
		print_r($array);
	}

	public static function calculateSpeed($start, $speed){
		return $start + $speed;
	}

}


/*
	$helpers = new Helpers();
	echo $helpers->cleanLastname("SKRZYPCZyk  ");
*/


echo Helpers::cleanLastname("SKRZYPCZyk  ");




